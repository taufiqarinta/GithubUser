package com.taufiqarinta.githubuser.data.response

data class UserResponse(
    val items : ArrayList<User>
)
